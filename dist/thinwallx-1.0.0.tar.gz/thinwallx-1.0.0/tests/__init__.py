"""ThinWallX test suite."""
